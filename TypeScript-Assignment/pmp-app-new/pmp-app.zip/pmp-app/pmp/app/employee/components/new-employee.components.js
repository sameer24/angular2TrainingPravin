"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var employee_1 = require("../models/employee");
var employee_service_1 = require("../services/employee-service");
var NewEmployeeComponents = (function () {
    function NewEmployeeComponents(_serviceEmp) {
        this._serviceEmp = _serviceEmp;
        this.title = "New Employee";
    }
    //@Input() event: Event;
    NewEmployeeComponents.prototype.ngOnInit = function () {
        this.newemployee = new employee_1.Employee();
    };
    NewEmployeeComponents.prototype.ngOnChanges = function () {
        // this.newEvent = this.event;
    };
    NewEmployeeComponents.prototype.insertEmployee = function () {
        var _this = this;
        this.newemployee.employeeForm.value.image = "images/noimage.png";
        this._serviceEmp.insertEmployee(this.newemployee.employeeForm.value).subscribe(function (data) {
            _this.newemployee = new employee_1.Employee();
            console.log("employee Added Successfully !");
        });
    };
    return NewEmployeeComponents;
}());
NewEmployeeComponents = __decorate([
    core_1.Component({
        selector: 'new-employee',
        templateUrl: 'app/employee/views/new-employee.component.html',
        styles: ['input.ng-invalid { border-left:3px solid red }', 'input.ng-valid { border-left:3px solid green }'],
        styleUrls: ['app/employee/css/employee.styles.css']
    }),
    __metadata("design:paramtypes", [employee_service_1.EmployeeService])
], NewEmployeeComponents);
exports.NewEmployeeComponents = NewEmployeeComponents;
//# sourceMappingURL=new-employee.components.js.map