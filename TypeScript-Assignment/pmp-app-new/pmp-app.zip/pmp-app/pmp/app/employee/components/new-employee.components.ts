import { Component, OnInit, Input, OnChanges } from "@angular/core";
import { Employee } from "../models/employee";
import { EmployeeService } from "../services/employee-service"

@Component({
    selector: 'new-employee',
    templateUrl: 'app/employee/views/new-employee.component.html',
    styles: ['input.ng-invalid { border-left:3px solid red }', 'input.ng-valid { border-left:3px solid green }'],
    styleUrls: ['app/employee/css/employee.styles.css']
})

export class NewEmployeeComponents implements OnInit, OnChanges {

    constructor(private _serviceEmp: EmployeeService) {
    }

    title: string = "New Employee";
    newemployee: Employee;
    //@Input() event: Event;

    ngOnInit() {
        this.newemployee = new Employee();      
    }

    ngOnChanges() {
        // this.newEvent = this.event;
    }

    insertEmployee(): void {
        this.newemployee.employeeForm.value.image = "images/noimage.png"
        this._serviceEmp.insertEmployee(this.newemployee.employeeForm.value).subscribe(
            data => {
                this.newemployee = new Employee();
                console.log("employee Added Successfully !")
            }
        )
    }

}