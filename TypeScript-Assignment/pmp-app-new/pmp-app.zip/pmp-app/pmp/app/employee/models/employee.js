"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var forms_1 = require("@angular/forms");
var Employee = (function () {
    function Employee() {
        // constructor(
        //     public employeeId?: string,
        //     public employeeCode?: string,
        //     public name?: string,
        //     public address?: string,
        //     public city?: string,
        //     public contact?: string,
        //     public email?: string,
        //     public designation?: string,
        //     public image?: string,
        //     public rating?: string,
        //     public _id?: string,
        // ) {
        // }
        this.employeeForm = new forms_1.FormGroup({
            employeeId: new forms_1.FormControl("000", forms_1.Validators.required),
            employeeCode: new forms_1.FormControl("SYN", [forms_1.Validators.required, forms_1.Validators.minLength(3), forms_1.Validators.maxLength(5)]),
            name: new forms_1.FormControl("-", forms_1.Validators.required),
            address: new forms_1.FormControl("-", forms_1.Validators.required),
            city: new forms_1.FormControl("-", forms_1.Validators.required),
            contact: new forms_1.FormControl("-", forms_1.Validators.required),
            email: new forms_1.FormControl(0, forms_1.Validators.required),
            designation: new forms_1.FormControl(0, forms_1.Validators.required),
            rating: new forms_1.FormControl(0, forms_1.Validators.required)
        });
    }
    return Employee;
}());
exports.Employee = Employee;
//# sourceMappingURL=employee.js.map