import { Component, Input,OnChanges } from "@angular/core";
import { Project } from "../models/project";
import { ProjectService } from "../services/project-service"

@Component({
    selector: 'project-details',
    templateUrl: 'app/project/views/project-details.component.html',
     styleUrls:['app/project/css/project.styles.css']
})

export class ProjectDetailsComponent  implements OnChanges{
    constructor(private _service: ProjectService) {      
    }

    title: string = "Project Details";
    @Input() id: string;
    project:Project;
     ngOnChanges() {
        this._service.getSingle(this.id).subscribe(
            data => this.project = data
        )
    } 
}