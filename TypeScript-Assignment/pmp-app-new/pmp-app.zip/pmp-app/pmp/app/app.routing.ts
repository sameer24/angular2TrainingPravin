import { ModuleWithProviders } from "@angular/core";
import { RouterModule, Routes } from "@angular/router"

import { HomeComponent } from "./home/components/home.component";

import { CompanyListComponents } from "./company/components/company-list.components";
import { CompanyDetailsComponent } from "./company/components/company-details.components";
import { NewCompanyComponents } from "./company/components/new-company.components";
 
import { EmployeeListComponents } from "./employee/components/employee-list.components";
import { EmployeeDetailsComponent } from "./employee/components/employee-details.components";
import { NewEmployeeComponents } from "./employee/components/new-employee.components";
 



const appRoutes: Routes = [
    {
        path: 'home', component: HomeComponent
    },
    {
        path: 'company', component: CompanyListComponents
    }, 
    {
        path: 'company/:id', component: CompanyDetailsComponent
    },
    {
        path: 'newcompany', component: NewCompanyComponents
    },
    {
        path: 'employee', component: EmployeeListComponents
    },
    {
         path: 'employee/:id', component: EmployeeDetailsComponent
    },
     {
         path: 'newemployee', component: NewEmployeeComponents
    },
    { 
        path: '', component: HomeComponent, pathMatch: 'full' 
    },
    {
        path: '**', component: HomeComponent
    }
]


export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);

