import { Component, Input,OnChanges } from "@angular/core";
import { Userstory } from "../models/us";
import { UserstoryService } from "../services/us-service"

@Component({
    selector: 'us-details',
    templateUrl: 'app/userstory/views/us-details.component.html',
     styleUrls:['app/userstory/css/us.styles.css']
})

export class UsersoryDetailsComponent  implements OnChanges{
    constructor(private _service: UserstoryService) {      
    }
    title: string = "Userstory Details";
    @Input() id: string;
    userstory:Userstory;
     ngOnChanges() {
        this._service.getSingle(this.id).subscribe(
            data => this.userstory = data
        )
    } 
}