import { Injectable } from "@angular/core";
import { Http } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import { Userstory } from "../models/us";

@Injectable()

export class UserstoryService {
    constructor(private _http: Http) {
    }
    
    getAll(): Observable<Userstory[]> {
        return this._http.get("http://localhost:8001/api/userstory").map(res => res.json());
    }

    getSingle(id: string): Observable<Userstory> {
        console.log(id);
        return this._http.get("http://localhost:8001/api/userstory/" + id).map(res => res.json());
    }
}