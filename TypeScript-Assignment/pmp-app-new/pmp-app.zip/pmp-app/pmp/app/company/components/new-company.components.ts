import { Component, OnInit, Input, OnChanges } from "@angular/core";
import { Company } from "../models/company";
import { CompanyService } from "../services/company-service"

@Component({
    selector: 'new-company',
    templateUrl: 'app/company/views/new-company.component.html',
    styles: ['input.ng-invalid { border-left:3px solid red }', 'input.ng-valid { border-left:3px solid green }'],
    styleUrls: ['app/company/css/company.styles.css']
})

export class NewCompanyComponents implements OnInit, OnChanges {

    constructor(private _serviceCompany: CompanyService) {
    }

    title: string = "New Company";
    newCompany: Company;
    //@Input() event: Event;

    ngOnInit() {
        this.newCompany = new Company();      
    }

    ngOnChanges() {
        // this.newEvent = this.event;
    }

    insertEvent(): void {
          this.newCompany.companyForm.value.image = "images/noimage.png"
        this._serviceCompany.insertEvents(this.newCompany.companyForm.value).subscribe(
            data => {
                this.newCompany = new Company();
                console.log("Company Added Successfully !")
            }
        )
    }
}