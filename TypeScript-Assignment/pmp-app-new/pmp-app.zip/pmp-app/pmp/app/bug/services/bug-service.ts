import { Injectable } from "@angular/core";
import { Http } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import { Bug } from "../models/bug";

@Injectable()

export class BugService {
    constructor(private _http: Http) {
    }
    
    getAll(): Observable<Bug[]> {
        return this._http.get("http://localhost:8001/api/bug").map(res => res.json());
    }

    getSingle(id: string): Observable<Bug> {
        console.log(id);
        return this._http.get("http://localhost:8001/api/bug/" + id).map(res => res.json());
    }
}