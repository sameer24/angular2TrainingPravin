import { Component, Input,OnChanges } from "@angular/core";
import { Bug } from "../models/bug";
import { BugService } from "../services/bug-service"

@Component({
    selector: 'bug-details',
    templateUrl: 'app/bug/views/bug-details.component.html',
     styleUrls:['app/bug/css/bug.styles.css']
})

export class BugDetailsComponent  implements OnChanges{
    constructor(private _service: BugService) {      
    }
    title: string = "Bug Details";
    @Input() id: string;
    bug:Bug;
     ngOnChanges() {
        this._service.getSingle(this.id).subscribe(
            data => this.bug = data
        )
    } 
}