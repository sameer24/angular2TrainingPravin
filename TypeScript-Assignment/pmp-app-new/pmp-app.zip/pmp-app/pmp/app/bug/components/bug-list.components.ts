
import { Component, OnInit } from "@angular/core";
import { Bug } from "../models/bug";
import { BugService } from "../services/bug-service"

@Component({
    selector: 'bug-list',
    templateUrl: 'app/bug/views/bug-list.component.html',
    styleUrls: ['app/bug/css/bug.styles.css']
})

export class BugListComponents implements OnInit {
    title: string = "Bug List";
    bug: Bug;
    searchLetterContains: string = "";
    bugs: Bug[];
    ngOnInit() {
        this._service.getAll().subscribe(
            data => this.bugs = data
        )
    }
    constructor(private _service: BugService) {
    }
}