import { Component, Input,OnChanges } from "@angular/core";
import { Task } from "../models/Task";
import { TaskService } from "../services/task-service"

@Component({
    selector: 'task-details',
    templateUrl: 'app/task/views/task-details.component.html',
     styleUrls:['app/task/css/task.styles.css']
})

export class TaskDetailsComponent  implements OnChanges{
    constructor(private _service: TaskService) {      
    }
    title: string = "Task Details";
    @Input() id: string;
    task:Task;
     ngOnChanges() {
        this._service.getSingle(this.id).subscribe(
            data => this.task = data
        )
    } 
}