import { Injectable } from "@angular/core";
import { Http } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import { Task } from "../models/Task";

@Injectable()

export class TaskService {
    constructor(private _http: Http) {
    }
    
    getAll(): Observable<Task[]> {
        return this._http.get("http://localhost:8001/api/task").map(res => res.json());
    }

    getSingle(id: string): Observable<Task> {
        console.log(id);
        return this._http.get("http://localhost:8001/api/task/" + id).map(res => res.json());
    }
}